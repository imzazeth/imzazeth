const suits = ['♠', '♥', '♦', '♣'];
const values = [
  {display: 'A', rank: 1},
  {display: '2', rank: 2},
  {display: '3', rank: 3},
  {display: '4', rank: 4},
  {display: '5', rank: 5},
  {display: '6', rank: 6},
  {display: '7', rank: 7},
  {display: '8', rank: 8},
  {display: '9', rank: 9},
  {display: '10', rank: 10},
  {display: 'J', rank: 11},
  {display: 'Q', rank: 12},
  {display: 'K', rank: 13}
];

let deck = [];
let currentCard = null;
let score = 0;
let gameOver = false;

function shuffleDeck() {
  deck = [];
  for (let suit of suits) {
    for (let val of values) {
      deck.push({ suit, display: val.display, rank: val.rank });
    }
  }
  for (let i = deck.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [deck[i], deck[j]] = [deck[j], deck[i]];
  }
}

function drawCard() {
  return deck.pop();
}

function renderCard(card) {
  return `<span style="color:${card.suit==='♥'||card.suit==='♦'?'#e94e77':'#fff'}">${card.display}${card.suit}</span>`;
}

function updateUI() {
  document.getElementById('current-card').innerHTML = renderCard(currentCard);
  document.getElementById('score').textContent = `Score: ${score}`;
  document.getElementById('result').textContent = '';
  document.getElementById('restart-btn').style.display = gameOver ? 'block' : 'none';
}

function startGame() {
  shuffleDeck();
  score = 0;
  gameOver = false;
  currentCard = drawCard();
  updateUI();
}

function handleGuess(type) {
  if (gameOver) return;
  const nextCard = drawCard();
  if (!nextCard) {
    document.getElementById('result').textContent = "No more cards! Final Score: " + score;
    gameOver = true;
    document.getElementById('restart-btn').style.display = 'block';
    return;
  }
  let correct = false;
  if (type === 'higher' && nextCard.rank > currentCard.rank) correct = true;
  if (type === 'lower' && nextCard.rank < currentCard.rank) correct = true;
  if (correct) {
    score++;
    document.getElementById('result').textContent = "Correct!";
  } else {
    document.getElementById('result').textContent = `Wrong! Card was ${renderCard(nextCard)}. Final Score: ${score}`;
    gameOver = true;
    document.getElementById('restart-btn').style.display = 'block';
  }
  currentCard = nextCard;
  updateUI();
}

document.getElementById('higher-btn').addEventListener('click', () => handleGuess('higher'));
document.getElementById('lower-btn').addEventListener('click', () => handleGuess('lower'));
document.getElementById('restart-btn').addEventListener('click', startGame);

window.onload = startGame;